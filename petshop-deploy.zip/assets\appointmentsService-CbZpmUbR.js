import{s as r}from"./index-DqfxtSNl.js";const o={async getAppointments(){try{const{data:e,error:t}=await r.from("appointments_pet").select(`
          *,
          pet:pets_pet(name, breed, image_url),
          service:services_pet(name, description, duration)
        `).order("appointment_date",{ascending:!0});return t?(console.warn("Error fetching appointments:",t.message),[]):e||[]}catch(e){return console.warn("Exception in getAppointments:",e),[]}},async getUpcomingAppointments(){try{const e=new Date().toISOString().split("T")[0],{data:t,error:n}=await r.from("appointments_pet").select(`
          *,
          pet:pets_pet(name, breed, image_url),
          service:services_pet(name, description, duration)
        `).gte("appointment_date",e).in("status",["pending","confirmed","in_progress"]).order("appointment_date",{ascending:!0});return n?(console.warn("Error fetching upcoming appointments:",n.message),[]):t||[]}catch(e){return console.warn("Exception in getUpcomingAppointments:",e),[]}},async getTodayAppointments(){try{const e=new Date().toISOString().split("T")[0],{data:t,error:n}=await r.from("appointments_pet").select(`
          *,
          pet:pets_pet(name, breed, image_url),
          service:services_pet(name, description, duration)
        `).eq("appointment_date",e).in("status",["confirmed","in_progress"]);return n?(console.warn("Error fetching today's appointments:",n.message),[]):t||[]}catch(e){return console.warn("Exception in getTodayAppointments:",e),[]}},async createAppointment(e){const{data:{user:t}}=await r.auth.getUser();if(!t)throw new Error("User not authenticated");const{data:n,error:a}=await r.from("appointments_pet").insert({...e,user_id:t.id}).select(`
        *,
        pet:pets_pet(name, breed, image_url),
        service:services_pet(name, description, duration)
      `).single();if(a)throw new Error(`Error creating appointment: ${a.message}`);return n},async updateAppointmentStatus(e,t){const{data:n,error:a}=await r.from("appointments_pet").update({status:t,updated_at:new Date().toISOString()}).eq("id",e).select(`
        *,
        pet:pets_pet(name, breed, image_url),
        service:services_pet(name, description, duration)
      `).single();if(a)throw new Error(`Error updating appointment: ${a.message}`);return n},async cancelAppointment(e){const{error:t}=await r.from("appointments_pet").update({status:"cancelled",updated_at:new Date().toISOString()}).eq("id",e);if(t)throw new Error(`Error cancelling appointment: ${t.message}`)}};export{o as a};
