import{c as B,s as n,r as b,b as R,j as e,m as f,C as T,k as F}from"./index-DqfxtSNl.js";import{T as G}from"./trending-up-CuENrwfF.js";import{C as I}from"./credit-card-BtP86Mcg.js";import{A}from"./award-CYu3Y2IQ.js";import{C as L}from"./check-BDt01QjK.js";import{H}from"./heart-akmbZfbn.js";/**
 * @license lucide-react v0.542.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const U=[["rect",{x:"3",y:"8",width:"18",height:"4",rx:"1",key:"bkv52"}],["path",{d:"M12 8v13",key:"1c76mn"}],["path",{d:"M19 12v7a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2v-7",key:"6wjy6b"}],["path",{d:"M7.5 8a2.5 2.5 0 0 1 0-5A4.8 8 0 0 1 12 8a4.8 8 0 0 1 4.5-5 2.5 2.5 0 0 1 0 5",key:"1ihvrl"}]],z=B("gift",U);class O{async getActivePlans(){const{data:r,error:s}=await n.from("subscription_plans_pet").select("*").eq("is_active",!0).order("sort_order",{ascending:!0});if(s)throw new Error(`Erro ao buscar planos de assinatura: ${s.message}`);return r||[]}async getPlanById(r){const{data:s,error:t}=await n.from("subscription_plans_pet").select("*").eq("id",r).single();if(t){if(t.code==="PGRST116")return null;throw new Error(`Erro ao buscar plano de assinatura: ${t.message}`)}return s}async getPlansByBillingCycle(r){const{data:s,error:t}=await n.from("subscription_plans_pet").select("*").eq("is_active",!0).eq("billing_cycle",r).order("sort_order",{ascending:!0});if(t)throw new Error(`Erro ao buscar planos por ciclo de cobrança: ${t.message}`);return s||[]}async createPlan(r){const{data:s,error:t}=await n.from("subscription_plans_pet").insert(r).select().single();if(t)throw new Error(`Erro ao criar plano de assinatura: ${t.message}`);return s}async updatePlan(r,s){const{data:t,error:i}=await n.from("subscription_plans_pet").update(s).eq("id",r).select().single();if(i)throw new Error(`Erro ao atualizar plano de assinatura: ${i.message}`);return t}async deletePlan(r){const{error:s}=await n.from("subscription_plans_pet").delete().eq("id",r);if(s)throw new Error(`Erro ao deletar plano de assinatura: ${s.message}`)}async togglePlanStatus(r){const{data:s,error:t}=await n.from("subscription_plans_pet").select("is_active").eq("id",r).single();if(t)throw new Error(`Erro ao buscar status do plano: ${t.message}`);const{data:i,error:c}=await n.from("subscription_plans_pet").update({is_active:!s.is_active}).eq("id",r).select().single();if(c)throw new Error(`Erro ao alterar status do plano: ${c.message}`);return i}async getPlanFeatures(r){const s=await this.getPlanById(r);if(!s)throw new Error("Plano não encontrado");return Array.isArray(s.features)?s.features:[]}async comparePlans(r){const{data:s,error:t}=await n.from("subscription_plans_pet").select("*").in("id",r).eq("is_active",!0).order("sort_order",{ascending:!0});if(t)throw new Error(`Erro ao comparar planos: ${t.message}`);return s||[]}async getRecommendedPlan(r,s){const i=(await this.getActivePlans()).filter(c=>c.max_pets>=r&&c.max_appointments>=s);return i.length===0?null:i.reduce((c,l)=>l.price<c.price?l:c)}async getPlanStats(r){const{data:s,error:t}=await n.from("user_subscriptions_pet").select("price, start_date, status").eq("plan_id",r);if(t)throw new Error(`Erro ao buscar estatísticas do plano: ${t.message}`);const i=(s==null?void 0:s.length)||0,c=(s==null?void 0:s.reduce((u,_)=>u+_.price,0))||0,l=new Date,d=(s==null?void 0:s.map(u=>{const _=new Date(u.start_date);return Math.floor((l.getTime()-_.getTime())/(1e3*60*60*24))}))||[],o=d.length>0?d.reduce((u,_)=>u+_,0)/d.length:0;return{totalSubscribers:i,monthlyRevenue:c,averageSubscriptionDuration:o}}async createBulkPlans(r){const{data:s,error:t}=await n.from("subscription_plans_pet").insert(r).select();if(t)throw new Error(`Erro ao criar planos em lote: ${t.message}`);return s||[]}async duplicatePlan(r,s){const t=await this.getPlanById(r);if(!t)throw new Error("Plano original não encontrado");const i={name:s,description:t.description,price:t.price,billing_cycle:t.billing_cycle,features:t.features,max_pets:t.max_pets,max_appointments:t.max_appointments,max_products_discount:t.max_products_discount,free_delivery:t.free_delivery,priority_support:t.priority_support,is_active:!1,sort_order:t.sort_order+1};return this.createPlan(i)}}const Y=new O;class V{async getUserSubscriptions(r){const{data:s,error:t}=await n.from("user_subscriptions_pet").select(`
        *,
        subscription_plans_pet (
          id,
          name,
          description,
          features,
          max_pets,
          max_appointments,
          max_products_discount,
          free_delivery,
          priority_support
        )
      `).eq("user_id",r).order("created_at",{ascending:!1});if(t)throw new Error(`Erro ao buscar assinaturas do usuário: ${t.message}`);return s||[]}async getActiveSubscription(r){const{data:s,error:t}=await n.from("user_subscriptions_pet").select(`
        *,
        subscription_plans_pet (
          id,
          name,
          description,
          features,
          max_pets,
          max_appointments,
          max_products_discount,
          free_delivery,
          priority_support
        )
      `).eq("user_id",r).eq("status","active").single();if(t){if(t.code==="PGRST116")return null;throw new Error(`Erro ao buscar assinatura ativa: ${t.message}`)}return s}async createSubscription(r){const{data:s,error:t}=await n.from("user_subscriptions_pet").insert(r).select(`
        *,
        subscription_plans_pet (
          id,
          name,
          description,
          features,
          max_pets,
          max_appointments,
          max_products_discount,
          free_delivery,
          priority_support
        )
      `).single();if(t)throw new Error(`Erro ao criar assinatura: ${t.message}`);return s}async updateSubscription(r,s){const{data:t,error:i}=await n.from("user_subscriptions_pet").update(s).eq("id",r).select(`
        *,
        subscription_plans_pet (
          id,
          name,
          description,
          features,
          max_pets,
          max_appointments,
          max_products_discount,
          free_delivery,
          priority_support
        )
      `).single();if(i)throw new Error(`Erro ao atualizar assinatura: ${i.message}`);return t}async cancelSubscription(r,s){return this.updateSubscription(r,{status:"cancelled",cancelled_at:new Date().toISOString(),cancellation_reason:s,auto_renew:!1})}async pauseSubscription(r){return this.updateSubscription(r,{status:"paused",auto_renew:!1})}async resumeSubscription(r){return this.updateSubscription(r,{status:"active",auto_renew:!0})}async upgradeSubscription(r,s){const{data:t,error:i}=await n.from("subscription_plans_pet").select("price, billing_cycle").eq("id",s).single();if(i||!t)throw new Error("Plano não encontrado");return this.updateSubscription(r,{plan_id:s,price:t.price,billing_cycle:t.billing_cycle})}async downgradeSubscription(r,s){const{data:t,error:i}=await n.from("subscription_plans_pet").select("price, billing_cycle").eq("id",s).single();if(i||!t)throw new Error("Plano não encontrado");return this.updateSubscription(r,{plan_id:s,price:t.price,billing_cycle:t.billing_cycle})}async getSubscriptionById(r){const{data:s,error:t}=await n.from("user_subscriptions_pet").select(`
        *,
        subscription_plans_pet (
          id,
          name,
          description,
          features,
          max_pets,
          max_appointments,
          max_products_discount,
          free_delivery,
          priority_support
        )
      `).eq("id",r).single();if(t){if(t.code==="PGRST116")return null;throw new Error(`Erro ao buscar assinatura: ${t.message}`)}return s}async getSubscriptionsByStatus(r){const{data:s,error:t}=await n.from("user_subscriptions_pet").select(`
        *,
        subscription_plans_pet (
          id,
          name,
          description,
          features,
          max_pets,
          max_appointments,
          max_products_discount,
          free_delivery,
          priority_support
        )
      `).eq("status",r).order("created_at",{ascending:!1});if(t)throw new Error(`Erro ao buscar assinaturas por status: ${t.message}`);return s||[]}async getExpiringSubscriptions(r=7){const s=new Date;s.setDate(s.getDate()+r);const{data:t,error:i}=await n.from("user_subscriptions_pet").select(`
        *,
        subscription_plans_pet (
          id,
          name,
          description,
          features,
          max_pets,
          max_appointments,
          max_products_discount,
          free_delivery,
          priority_support
        )
      `).eq("status","active").lte("next_billing_date",s.toISOString()).order("next_billing_date",{ascending:!0});if(i)throw new Error(`Erro ao buscar assinaturas expirando: ${i.message}`);return t||[]}async getSubscriptionStats(r){const s=await this.getUserSubscriptions(r),t=s.length,i=s.filter(o=>o.status==="active").length,c=s.reduce((o,u)=>o+u.price,0),l=s.filter(o=>o.billing_cycle==="monthly"),d=l.length>0?l.reduce((o,u)=>o+u.price,0)/l.length:0;return{totalSubscriptions:t,activeSubscriptions:i,totalSpent:c,averageMonthlySpend:d}}async checkSubscriptionLimits(r){const s=await this.getActiveSubscription(r);if(!s)return{canAddPet:!1,canScheduleAppointment:!1,remainingPets:0,remainingAppointments:0};const t=s.subscription_plans_pet,{count:i}=await n.from("pets_pet").select("*",{count:"exact",head:!0}).eq("user_id",r),{count:c}=await n.from("appointments_pet").select("*",{count:"exact",head:!0}).eq("user_id",r),l=Math.max(0,t.max_pets-(i||0)),d=Math.max(0,t.max_appointments-(c||0));return{canAddPet:l>0,canScheduleAppointment:d>0,remainingPets:l,remainingAppointments:d}}async renewSubscription(r){const s=await this.getSubscriptionById(r);if(!s)throw new Error("Assinatura não encontrada");const t=new Date;return s.billing_cycle==="monthly"?t.setMonth(t.getMonth()+1):s.billing_cycle==="quarterly"?t.setMonth(t.getMonth()+3):s.billing_cycle==="yearly"&&t.setFullYear(t.getFullYear()+1),this.updateSubscription(r,{status:"active",next_billing_date:t.toISOString(),auto_renew:!0})}async getSubscriptionHistory(r){const{data:s,error:t}=await n.from("user_subscriptions_pet").select(`
        *,
        subscription_plans_pet (
          id,
          name,
          description,
          features,
          max_pets,
          max_appointments,
          max_products_discount,
          free_delivery,
          priority_support
        )
      `).eq("user_id",r).order("created_at",{ascending:!1});if(t)throw new Error(`Erro ao buscar histórico de assinaturas: ${t.message}`);return s||[]}}const y=new V,ee=()=>{var P;const[j,r]=b.useState(""),[s,t]=b.useState("monthly"),[i,c]=b.useState(!0),[l,d]=b.useState(null),{user:o}=R(),[u,_]=b.useState([]),[m,v]=b.useState(null),[w,N]=b.useState(null);b.useEffect(()=>{(async()=>{if(!o){c(!1);return}try{c(!0);const[p,x,h]=await Promise.all([Y.getActivePlans(),y.getActiveSubscription(o.id),y.getSubscriptionStats(o.id)]);_(p),v(x),N(h),x?r(x.plan_id):p.length>0&&r(p[0].id)}catch(p){d(p instanceof Error?p.message:"Erro ao carregar dados")}finally{c(!1)}})()},[o]);const g=u.filter(a=>a.billing_cycle===s),k=a=>{switch(a.toLowerCase()){case"básico":return H;case"premium":return F;case"família":return z;default:return A}},$=a=>{switch(a.toLowerCase()){case"básico":return"secondary";case"premium":return"primary";case"família":return"accent";default:return"primary"}},C=async a=>{var p;if(!o){d("Você precisa estar logado para assinar um plano");return}try{await y.createSubscription({user_id:o.id,plan_id:a,billing_cycle:s,price:((p=u.find(S=>S.id===a))==null?void 0:p.price)||0,status:"active",auto_renew:!0});const[x,h]=await Promise.all([y.getActiveSubscription(o.id),y.getSubscriptionStats(o.id)]);v(x),N(h)}catch(x){d(x instanceof Error?x.message:"Erro ao assinar plano")}},q=async()=>{if(m)try{await y.cancelSubscription(m.id,"Cancelado pelo usuário");const[a,p]=await Promise.all([y.getActiveSubscription(o.id),y.getSubscriptionStats(o.id)]);v(a),N(p)}catch(a){d(a instanceof Error?a.message:"Erro ao cancelar assinatura")}};return i?e.jsx("div",{className:"min-h-screen bg-surface pt-8 pb-12 flex items-center justify-center",children:e.jsxs("div",{className:"text-center",children:[e.jsx("div",{className:"animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto"}),e.jsx("p",{className:"mt-4 text-text-color",children:"Carregando planos..."})]})}):l?e.jsx("div",{className:"min-h-screen bg-surface pt-8 pb-12 flex items-center justify-center",children:e.jsxs("div",{className:"text-center",children:[e.jsx("p",{className:"text-red-600 mb-4",children:l}),e.jsx("button",{onClick:()=>window.location.reload(),className:"bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary-dark",children:"Tentar novamente"})]})}):e.jsx("div",{className:"min-h-screen bg-surface pt-8 pb-12",children:e.jsxs("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8",children:[e.jsxs(f.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},className:"text-center mb-12",children:[e.jsx("h1",{className:"text-4xl font-extrabold text-text-color-dark mb-4",children:"Planos de Assinatura"}),e.jsx("p",{className:"text-text-color text-lg max-w-3xl mx-auto",children:"Escolha o plano perfeito para dar o melhor cuidado ao seu pet. Todos os planos incluem acesso completo aos nossos serviços."})]}),e.jsx(f.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1},className:"flex justify-center mb-8",children:e.jsxs("div",{className:"bg-white rounded-xl p-1 shadow-sm border border-accent/20",children:[e.jsx("button",{onClick:()=>t("monthly"),className:`px-6 py-2 rounded-lg font-medium transition-colors ${s==="monthly"?"bg-primary text-white":"text-text-color hover:bg-surface-dark"}`,children:"Mensal"}),e.jsxs("button",{onClick:()=>t("yearly"),className:`px-6 py-2 rounded-lg font-medium transition-colors ${s==="yearly"?"bg-primary text-white":"text-text-color hover:bg-surface-dark"}`,children:["Anual",e.jsx("span",{className:"ml-2 text-xs bg-status-success text-white px-2 py-1 rounded-full",children:"-20%"})]})]})}),m&&e.jsx(f.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.2},className:"bg-gradient-to-r from-primary to-primary-dark rounded-2xl p-6 mb-8 text-white",children:e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{children:[e.jsxs("h3",{className:"text-xl font-bold mb-2",children:["Assinatura Ativa: ",((P=m.subscription_plans_pet)==null?void 0:P.name)||"Plano Ativo"]}),e.jsxs("p",{className:"text-primary-light",children:["Próxima cobrança: ",m.next_billing_date?new Date(m.next_billing_date).toLocaleDateString("pt-BR"):"N/A"]})]}),e.jsx("button",{onClick:q,className:"bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg transition-colors",children:"Cancelar"})]})}),w&&e.jsxs(f.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.3},className:"grid grid-cols-1 md:grid-cols-4 gap-4 mb-8",children:[e.jsx("div",{className:"bg-white rounded-xl p-4 shadow-sm border border-accent/20",children:e.jsxs("div",{className:"flex items-center",children:[e.jsx(G,{className:"h-8 w-8 text-primary mr-3"}),e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-text-color",children:"Total Gasto"}),e.jsxs("p",{className:"text-xl font-bold text-text-color-dark",children:["R$ ",w.totalSpent.toFixed(2)]})]})]})}),e.jsx("div",{className:"bg-white rounded-xl p-4 shadow-sm border border-accent/20",children:e.jsxs("div",{className:"flex items-center",children:[e.jsx(T,{className:"h-8 w-8 text-accent mr-3"}),e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-text-color",children:"Assinaturas Ativas"}),e.jsx("p",{className:"text-xl font-bold text-text-color-dark",children:w.activeSubscriptions})]})]})}),e.jsx("div",{className:"bg-white rounded-xl p-4 shadow-sm border border-accent/20",children:e.jsxs("div",{className:"flex items-center",children:[e.jsx(I,{className:"h-8 w-8 text-status-success mr-3"}),e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-text-color",children:"Gasto Médio Mensal"}),e.jsxs("p",{className:"text-xl font-bold text-text-color-dark",children:["R$ ",w.averageMonthlySpend.toFixed(2)]})]})]})}),e.jsx("div",{className:"bg-white rounded-xl p-4 shadow-sm border border-accent/20",children:e.jsxs("div",{className:"flex items-center",children:[e.jsx(A,{className:"h-8 w-8 text-status-warning mr-3"}),e.jsxs("div",{children:[e.jsx("p",{className:"text-sm text-text-color",children:"Total de Assinaturas"}),e.jsx("p",{className:"text-xl font-bold text-text-color-dark",children:w.totalSubscriptions})]})]})})]}),e.jsx(f.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.4},className:"grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12",children:g.map((a,p)=>{const x=k(a.name),h=$(a.name),S=j===a.id,E=(m==null?void 0:m.plan_id)===a.id;return e.jsxs(f.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.1*p},className:`relative bg-white rounded-2xl shadow-lg border-2 transition-all duration-300 ${S?"border-primary shadow-primary/20":"border-accent/20 hover:border-primary/50"} ${E?"ring-2 ring-primary/20":""}`,children:[E&&e.jsx("div",{className:"absolute -top-3 left-1/2 transform -translate-x-1/2",children:e.jsx("span",{className:"bg-primary text-white px-4 py-1 rounded-full text-sm font-medium",children:"Plano Atual"})}),e.jsxs("div",{className:"p-6",children:[e.jsxs("div",{className:"flex items-center mb-4",children:[e.jsx("div",{className:`p-3 rounded-xl ${h==="primary"?"bg-primary/10":h==="secondary"?"bg-secondary/10":"bg-accent/10"}`,children:e.jsx(x,{className:`h-6 w-6 ${h==="primary"?"text-primary":h==="secondary"?"text-secondary":"text-accent"}`})}),e.jsxs("div",{className:"ml-4",children:[e.jsx("h3",{className:"text-xl font-bold text-text-color-dark",children:a.name}),e.jsx("p",{className:"text-text-color text-sm",children:a.description})]})]}),e.jsxs("div",{className:"mb-6",children:[e.jsxs("div",{className:"flex items-baseline",children:[e.jsxs("span",{className:"text-4xl font-bold text-text-color-dark",children:["R$ ",a.price.toFixed(2)]}),e.jsxs("span",{className:"text-text-color ml-2",children:["/",a.billing_cycle==="monthly"?"mês":"ano"]})]}),a.billing_cycle==="yearly"&&e.jsx("p",{className:"text-sm text-status-success mt-1",children:"Economize 20% comparado ao plano mensal"})]}),e.jsx("div",{className:"space-y-3 mb-6",children:Array.isArray(a.features)&&a.features.map((D,M)=>e.jsxs("div",{className:"flex items-center",children:[e.jsx(L,{className:"h-5 w-5 text-status-success mr-3 flex-shrink-0"}),e.jsx("span",{className:"text-text-color",children:D})]},M))}),e.jsxs("div",{className:"space-y-2 mb-6 text-sm text-text-color",children:[e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:"Máximo de pets:"}),e.jsx("span",{className:"font-medium",children:a.max_pets})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:"Agendamentos:"}),e.jsx("span",{className:"font-medium",children:a.max_appointments===999?"Ilimitados":a.max_appointments})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:"Desconto em produtos:"}),e.jsxs("span",{className:"font-medium",children:[a.max_products_discount,"%"]})]}),e.jsxs("div",{className:"flex justify-between",children:[e.jsx("span",{children:"Frete grátis:"}),e.jsx("span",{className:"font-medium",children:a.free_delivery?"Sim":"Não"})]})]}),!E&&e.jsx("button",{onClick:()=>C(a.id),className:`w-full py-3 px-4 rounded-lg font-medium transition-colors ${h==="primary"?"bg-primary text-white hover:bg-primary-dark":h==="secondary"?"bg-secondary text-white hover:bg-secondary-dark":"bg-accent text-white hover:bg-accent-dark"}`,children:m?"Trocar Plano":"Assinar Agora"})]})]},a.id)})}),e.jsxs(f.div,{initial:{opacity:0,y:20},animate:{opacity:1,y:0},transition:{delay:.5},className:"bg-white rounded-2xl shadow-lg p-8",children:[e.jsx("h3",{className:"text-2xl font-bold text-text-color-dark mb-6 text-center",children:"Comparação de Recursos"}),e.jsx("div",{className:"overflow-x-auto",children:e.jsxs("table",{className:"w-full",children:[e.jsx("thead",{children:e.jsxs("tr",{className:"border-b border-accent/20",children:[e.jsx("th",{className:"text-left py-3 px-4 font-medium text-text-color-dark",children:"Recursos"}),g.map(a=>e.jsx("th",{className:"text-center py-3 px-4 font-medium text-text-color-dark",children:a.name},a.id))]})}),e.jsxs("tbody",{children:[e.jsxs("tr",{className:"border-b border-accent/10",children:[e.jsx("td",{className:"py-3 px-4 text-text-color",children:"Máximo de pets"}),g.map(a=>e.jsx("td",{className:"text-center py-3 px-4",children:a.max_pets},a.id))]}),e.jsxs("tr",{className:"border-b border-accent/10",children:[e.jsx("td",{className:"py-3 px-4 text-text-color",children:"Agendamentos"}),g.map(a=>e.jsx("td",{className:"text-center py-3 px-4",children:a.max_appointments===999?"Ilimitados":a.max_appointments},a.id))]}),e.jsxs("tr",{className:"border-b border-accent/10",children:[e.jsx("td",{className:"py-3 px-4 text-text-color",children:"Desconto em produtos"}),g.map(a=>e.jsxs("td",{className:"text-center py-3 px-4",children:[a.max_products_discount,"%"]},a.id))]}),e.jsxs("tr",{className:"border-b border-accent/10",children:[e.jsx("td",{className:"py-3 px-4 text-text-color",children:"Frete grátis"}),g.map(a=>e.jsx("td",{className:"text-center py-3 px-4",children:a.free_delivery?"✓":"✗"},a.id))]}),e.jsxs("tr",{children:[e.jsx("td",{className:"py-3 px-4 text-text-color",children:"Suporte prioritário"}),g.map(a=>e.jsx("td",{className:"text-center py-3 px-4",children:a.priority_support?"✓":"✗"},a.id))]})]})]})})]})]})})};export{ee as default};
