import{s,l as c}from"./index-DqfxtSNl.js";const p={async getAdminUsers(){try{const{data:e,error:t}=await s.from("profiles_pet").select("id, full_name, email, phone").limit(10);if(t)throw t;const r=(e||[]).map(a=>({id:`temp-admin-${a.id}`,user_id:a.id,role:"admin",permissions:{all:!0,users:!0,reports:!0,settings:!0,tickets:!0,logs:!0,security:!0},is_active:!0,created_at:new Date().toISOString(),updated_at:new Date().toISOString(),profiles_pet:{full_name:a.full_name,email:a.email,phone:a.phone||""}}));return c.info("Admin users fetched successfully (temporary fix)",{count:r.length},"ADMIN"),r}catch(e){throw c.error("Error fetching admin users",e,{},"ADMIN"),e}},async createAdminUser(e,t,r={}){try{const{data:a,error:i}=await s.from("admin_users_pet").insert({user_id:e,role:t,permissions:r}).select(`
          *,
          profiles_pet (
            full_name,
            email,
            phone
          )
        `).single();if(i)throw i;return await this.logAdminAction("create_admin_user","admin_user",a.id,{user_id:e,role:t,permissions:r}),c.info("Admin user created successfully",{adminId:a.id,userId:e,role:t},"ADMIN"),a}catch(a){throw c.error("Error creating admin user",a,{userId:e,role:t},"ADMIN"),a}},async updateAdminUser(e,t){try{const{data:r,error:a}=await s.from("admin_users_pet").update(t).eq("id",e).select(`
          *,
          profiles_pet (
            full_name,
            email,
            phone
          )
        `).single();if(a)throw a;return await this.logAdminAction("update_admin_user","admin_user",e,t),c.info("Admin user updated successfully",{adminId:e,updates:t},"ADMIN"),r}catch(r){throw c.error("Error updating admin user",r,{adminId:e,updates:t},"ADMIN"),r}},async deleteAdminUser(e){try{const{error:t}=await s.from("admin_users_pet").delete().eq("id",e);if(t)throw t;await this.logAdminAction("delete_admin_user","admin_user",e,{}),c.info("Admin user deleted successfully",{adminId:e},"ADMIN")}catch(t){throw c.error("Error deleting admin user",t,{adminId:e},"ADMIN"),t}},async getAdminLogs(e=100,t=0){try{const{data:r,error:a}=await s.from("admin_logs_pet").select(`
          *,
          admin_users_pet (
            profiles_pet (
              full_name,
              email
            )
          )
        `).order("created_at",{ascending:!1}).range(t,t+e-1);if(a)throw a;return r||[]}catch(r){throw c.error("Error fetching admin logs",r,{},"ADMIN"),r}},async logAdminAction(e,t,r,a={}){try{const{data:{user:i}}=await s.auth.getUser();if(!i)return;const{data:n}=await s.from("admin_users_pet").select("id").eq("user_id",i.id).single();if(!n)return;const{error:o}=await s.from("admin_logs_pet").insert({admin_id:n.id,action:e,resource_type:t,resource_id:r,details:a,ip_address:null,user_agent:navigator.userAgent});if(o)throw o;c.debug("Admin action logged",{action:e,resourceType:t,resourceId:r},"ADMIN")}catch(i){c.error("Error logging admin action",i,{action:e,resourceType:t,resourceId:r},"ADMIN")}},async getSystemSettings(){try{const{data:e,error:t}=await s.from("system_settings_pet").select("*").order("category",{ascending:!0});if(t)throw t;return e||[]}catch(e){throw c.error("Error fetching system settings",e,{},"ADMIN"),e}},async updateSystemSetting(e,t){try{const{data:r,error:a}=await s.from("system_settings_pet").update({value:t}).eq("key",e).select("*").single();if(a)throw a;return await this.logAdminAction("update_system_setting","system_setting",e,{value:t}),c.info("System setting updated",{key:e,value:t},"ADMIN"),r}catch(r){throw c.error("Error updating system setting",r,{key:e,value:t},"ADMIN"),r}},async generateReport(e,t,r={}){try{const{data:{user:a}}=await s.auth.getUser();if(!a)throw new Error("User not authenticated");const{data:i}=await s.from("admin_users_pet").select("id").eq("user_id",a.id).single();if(!i)throw new Error("User is not an admin");let n={};switch(t){case"revenue":n=await this.generateRevenueReport(r);break;case"users":n=await this.generateUsersReport(r);break;case"appointments":n=await this.generateAppointmentsReport(r);break;case"products":n=await this.generateProductsReport(r);break;case"orders":n=await this.generateOrdersReport(r);break;default:throw new Error("Invalid report type")}const{data:o,error:l}=await s.from("admin_reports_pet").insert({name:e,type:t,parameters:r,data:n,generated_by:i.id,expires_at:new Date(Date.now()+10080*60*1e3).toISOString()}).select("*").single();if(l)throw l;return await this.logAdminAction("generate_report","report",o.id,{name:e,type:t,parameters:r}),c.info("Report generated successfully",{reportId:o.id,name:e,type:t},"ADMIN"),o}catch(a){throw c.error("Error generating report",a,{name:e,type:t,parameters:r},"ADMIN"),a}},async getReports(){try{const{data:e,error:t}=await s.from("admin_reports_pet").select("*").order("generated_at",{ascending:!1});if(t)throw t;return e||[]}catch(e){throw c.error("Error fetching reports",e,{},"ADMIN"),e}},async getAdminNotifications(){try{const{data:{user:e}}=await s.auth.getUser();if(!e)return[];const{data:t}=await s.from("admin_users_pet").select("id").eq("user_id",e.id).single();if(!t)return[];const{data:r,error:a}=await s.from("admin_notifications_pet").select("*").eq("admin_id",t.id).order("created_at",{ascending:!1});if(a)throw a;return r||[]}catch(e){throw c.error("Error fetching admin notifications",e,{},"ADMIN"),e}},async markNotificationAsRead(e){try{const{error:t}=await s.from("admin_notifications_pet").update({is_read:!0,read_at:new Date().toISOString()}).eq("id",e);if(t)throw t;c.info("Notification marked as read",{notificationId:e},"ADMIN")}catch(t){throw c.error("Error marking notification as read",t,{notificationId:e},"ADMIN"),t}},async getSupportTickets(e=50,t=0){try{const{data:r,error:a}=await s.from("support_tickets_pet").select(`
          *,
          profiles_pet (
            full_name,
            email,
            phone
          ),
          admin_users_pet (
            profiles_pet (
              full_name,
              email
            )
          )
        `).order("created_at",{ascending:!1}).range(t,t+e-1);if(a)throw a;return r||[]}catch(r){throw c.error("Error fetching support tickets",r,{},"ADMIN"),r}},async updateSupportTicket(e,t){try{const{data:r,error:a}=await s.from("support_tickets_pet").update(t).eq("id",e).select(`
          *,
          profiles_pet (
            full_name,
            email,
            phone
          ),
          admin_users_pet (
            profiles_pet (
              full_name,
              email
            )
          )
        `).single();if(a)throw a;return await this.logAdminAction("update_support_ticket","support_ticket",e,t),c.info("Support ticket updated",{ticketId:e,updates:t},"ADMIN"),r}catch(r){throw c.error("Error updating support ticket",r,{ticketId:e,updates:t},"ADMIN"),r}},async generateRevenueReport(e){const{startDate:t,endDate:r}=e,a=t||new Date(Date.now()-720*60*60*1e3).toISOString(),i=r||new Date().toISOString(),{data:n}=await s.from("orders_pet").select("total_amount, created_at, status").gte("created_at",a).lte("created_at",i),{data:o}=await s.from("user_subscriptions_pet").select("monthly_price, created_at, status").gte("created_at",a).lte("created_at",i),l=(n||[]).reduce((u,g)=>u+(g.total_amount||0),0),d=(o||[]).reduce((u,g)=>u+(g.monthly_price||0),0);return{period:{start:a,end:i},totalRevenue:l,subscriptionRevenue:d,orderCount:(n==null?void 0:n.length)||0,subscriptionCount:(o==null?void 0:o.length)||0,averageOrderValue:n!=null&&n.length?l/n.length:0}},async generateUsersReport(e){const{startDate:t,endDate:r}=e,a=t||new Date(Date.now()-720*60*60*1e3).toISOString(),i=r||new Date().toISOString(),{data:n}=await s.from("profiles_pet").select("created_at").gte("created_at",a).lte("created_at",i),{data:o}=await s.from("profiles_pet").select("id",{count:"exact"});return{period:{start:a,end:i},newUsers:(n==null?void 0:n.length)||0,totalUsers:(o==null?void 0:o.length)||0,growthRate:o!=null&&o.length?((n==null?void 0:n.length)||0)/o.length*100:0}},async generateAppointmentsReport(e){const{startDate:t,endDate:r}=e,a=t||new Date(Date.now()-720*60*60*1e3).toISOString(),i=r||new Date().toISOString(),{data:n}=await s.from("appointments_pet").select("status, total_price, created_at").gte("created_at",a).lte("created_at",i),o=(n||[]).reduce((d,u)=>(d[u.status]=(d[u.status]||0)+1,d),{}),l=(n||[]).reduce((d,u)=>d+(u.total_price||0),0);return{period:{start:a,end:i},totalAppointments:(n==null?void 0:n.length)||0,statusCounts:o,totalRevenue:l,averageAppointmentValue:n!=null&&n.length?l/n.length:0}},async generateProductsReport(e){const{data:t}=await s.from("products_pet").select("name, price, stock, is_active"),r=(t||[]).filter(n=>n.is_active),a=(t||[]).filter(n=>(n.stock||0)<10),i=(t||[]).reduce((n,o)=>n+(o.price||0)*(o.stock||0),0);return{totalProducts:(t==null?void 0:t.length)||0,activeProducts:r.length,lowStockProducts:a.length,totalInventoryValue:i,averagePrice:t!=null&&t.length?t.reduce((n,o)=>n+(o.price||0),0)/t.length:0}},async generateOrdersReport(e){const{startDate:t,endDate:r}=e,a=t||new Date(Date.now()-720*60*60*1e3).toISOString(),i=r||new Date().toISOString(),{data:n}=await s.from("orders_pet").select("status, total_amount, created_at").gte("created_at",a).lte("created_at",i),o=(n||[]).reduce((d,u)=>(d[u.status]=(d[u.status]||0)+1,d),{}),l=(n||[]).reduce((d,u)=>d+(u.total_amount||0),0);return{period:{start:a,end:i},totalOrders:(n==null?void 0:n.length)||0,statusCounts:o,totalRevenue:l,averageOrderValue:n!=null&&n.length?l/n.length:0}}};export{p as a};
